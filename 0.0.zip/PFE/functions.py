from flask import render_template,redirect , url_for
from database_creator import *
# tous les fonctions utils
from flask import session

# ---- Session ----- 
def save_session(data:dict):
    for key ,value in data.items() :
        session[key] = value
    print("session saved!")
def session_exists():
    return "userid" in session

# ---- POST data ----
def user_exists(username:str):
    result = cursor.execute(f"SELECT username,password from users where username = '{username}'")
    result = cursor.fetchone() # si une ligne exist au min
    return result is not None

def empty(data:str):
    return data == ""