
from flask import render_template , url_for , redirect , request
from functions import *


def init_routes(app):
    @app.route("/")
    def home():
        # verify if there is a session , else => redirect to login
        Session = False # the session 
        if Session :
            return render_template("home.html")
        else :
            redirect(url_for())

    @app.route("/login",methods=["POST","GET"])
    def login():
        if session_exists() :
            # redirect to home
            return redirect(url_for('home'))
        else :
            # if request is post
            if request.method == "POST" :
                # get infos
                